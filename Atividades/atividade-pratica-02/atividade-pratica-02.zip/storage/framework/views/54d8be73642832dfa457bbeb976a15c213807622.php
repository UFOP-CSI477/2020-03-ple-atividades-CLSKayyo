

<?php $__env->startSection('content'); ?>

    <h1>Dados do Registro de Manutenção</h1>

    <p><b>ID:</b> <?php echo e($registro->id); ?></p>
    <p><b>Equipamento:</b> <a href="<?php echo e(route('equipamentos.show', $registro->equipamento->id)); ?>"><?php echo e($registro->equipamento->nome); ?></a></p>
    <p><b>Criador do registro:</b> <?php echo e($registro->user->name); ?></p>
    <p><b>Data Limite para realização da Manutenção:</b> <?php echo e($registro->datalimite); ?></p>
    <p><b>Descrição da Manutenção:</b> <?php echo e($registro->descricao); ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/registros/show.blade.php ENDPATH**/ ?>