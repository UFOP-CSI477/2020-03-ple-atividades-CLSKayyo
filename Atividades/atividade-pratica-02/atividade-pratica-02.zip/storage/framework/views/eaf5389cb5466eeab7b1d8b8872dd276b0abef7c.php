

<?php $__env->startSection('content'); ?>

    <h1>Manutenções</h1>

    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>Data Limite</th>
                <th>ID</th>
                <th>Descrição</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($registro->datalimite); ?></th>
                    <td><?php echo e($registro->id); ?></td>
                    <td><?php echo e($registro->descricao); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/registros.blade.php ENDPATH**/ ?>