

<?php $__env->startSection('content'); ?>

    <h1>Usuários</h1>

    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>Nome</th>
                <th>ID</th>
                <th>E-mail</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($usuario->name); ?>

                    <?php if($usuario->id == Auth::user()->id): ?>
                        <sub> você</sub>
                    <?php endif; ?>
                    </th>
                    <td><?php echo e($usuario->id); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/users.blade.php ENDPATH**/ ?>