

<?php $__env->startSection('content'); ?>

    <h1>Equipamentos</h1>

    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>Nome</th>
                <th>ID</th>
                <th>Data de Criação</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $equipamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($equipamento->nome); ?></th>
                    <td><?php echo e($equipamento->id); ?></td>
                    <td><?php echo e(date('G:i:s d/m/Y',strtotime($equipamento->created_at))); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('suporte.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/suporte/equipamentos.blade.php ENDPATH**/ ?>