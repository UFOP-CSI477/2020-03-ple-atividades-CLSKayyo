

<?php $__env->startSection('content'); ?>

    <div class="criar">
        <h1>Editar Equipamento de ID <?php echo e($equipamento->id); ?></h1>

        <form action="<?php echo e(route('equipamentos.update', $equipamento)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do Equipamento" value="<?php echo e($equipamento->nome); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Editar Equipamento</button>
        </form>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/equipamentos/edit.blade.php ENDPATH**/ ?>