

<?php $__env->startSection('content'); ?>

    <?php if(session('mensagem')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensagem')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('erro')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('erro')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col"><h1 class="title">Equipamentos</h1></div>
        <div class="col">
            <a href="<?php echo e(route('equipamentos.create')); ?>"><button class="btn-adicionar btn btn-outline-success ml-auto">Criar Equipamento</button></a>
        </div>
    </div>
    

    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Data de Criação</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $equipamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($equipamento->id); ?></th>
                    <td><?php echo e($equipamento->nome); ?></td>
                    <td><?php echo e(date('G:i:s d/m/Y',strtotime($equipamento->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('equipamentos.show', $equipamento->id)); ?>"><button class="btn btn-sm btn-outline-primary">Exibir</button></a>
                        <a href="<?php echo e(route('equipamentos.edit', $equipamento->id)); ?>"><button class="btn btn-sm btn-outline-warning">Editar</button></a>
                        <form action="<?php echo e(route('equipamentos.destroy', $equipamento->id)); ?>" method="post" class="excluir" onsubmit="return confirm('Tem certeza que deseja excluir <?php echo e($equipamento->nome); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/equipamentos/index.blade.php ENDPATH**/ ?>