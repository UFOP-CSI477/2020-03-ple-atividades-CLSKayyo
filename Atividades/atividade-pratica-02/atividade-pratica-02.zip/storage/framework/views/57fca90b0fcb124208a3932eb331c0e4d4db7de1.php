

<?php $__env->startSection('content'); ?>

    <h1>Dados do Equipamento</h1>

    <p><b>ID:</b> <?php echo e($equipamento->id); ?></p>
    <p><b>Nome:</b> <?php echo e($equipamento->nome); ?></p>
    <p><b>Criado em:</b> <?php echo e($equipamento->created_at); ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/equipamentos/show.blade.php ENDPATH**/ ?>