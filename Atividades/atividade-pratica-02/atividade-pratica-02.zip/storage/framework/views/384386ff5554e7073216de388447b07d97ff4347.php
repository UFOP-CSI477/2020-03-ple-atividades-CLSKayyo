

<?php $__env->startSection('content'); ?>

    <div class="criar">
        <h1>Criar Novo Equipamento</h1>

        <form action="<?php echo e(route('equipamentos.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do Equipamento">
            </div>
            <button type="submit" class="btn btn-primary">Adicionar Equipamento</button>
        </form>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/equipamentos/create.blade.php ENDPATH**/ ?>