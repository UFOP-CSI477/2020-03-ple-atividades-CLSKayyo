

<?php $__env->startSection('content'); ?>

    <div class="criar">
        <h1>Criar Novo Registro de Manutenção</h1>

        <form action="<?php echo e(route('registros.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <div class="form-group">
                <select class="form-control" id="equipamento_id" name="equipamento_id" placeholder="Equipamento">
                    <?php $__currentLoopData = $equipamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($equipamento->id); ?>"><?php echo e($equipamento->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <select class="form-control" id="tipo" name="tipo" placeholder="Tipo de Manutenção">
                    <option value="1">Preventiva</option>
                    <option value="2">Corretiva</option>
                    <option value="3">Urgente</option>
                </select>
            </div>
            <div class="form-group">
                <input type="date" class="form-control" id="datalimite" name="datalimite" placeholder="Nome do Equipamento">
            </div>
            <div class="form-group">
                <textarea class="form-control" id="descricao" name="descricao" placeholder="Descrição da Manutenção"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar Registro</button>
        </form>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/registros/create.blade.php ENDPATH**/ ?>