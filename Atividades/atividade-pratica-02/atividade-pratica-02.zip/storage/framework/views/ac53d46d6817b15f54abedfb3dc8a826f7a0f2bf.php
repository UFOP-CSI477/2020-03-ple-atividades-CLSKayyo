

<?php $__env->startSection('content'); ?>

    <h1>Relatório de Manutenções por Equipamento</h1>

    <div class="accordion" id="conjuntos-equipamentos">
        <?php $__currentLoopData = $equipamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card">
                <div class="card-header" id="equipamento-<?php echo e($equipamento->id); ?>">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($equipamento->id); ?>" aria-expanded="true" aria-controls="collapse-<?php echo e($equipamento->id); ?>">
                        <?php echo e($equipamento->nome); ?>

                        </button>
                    </h2>
                    </div>

                    <div id="collapse-<?php echo e($equipamento->id); ?>" class="collapse" aria-labelledby="equipamento-<?php echo e($equipamento->id); ?>" data-parent="#conjuntos-equipamentos">
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Data Limite</th>
                                    <th>ID</th>
                                    <th>Usuário</th>
                                    <th>Tipo</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $equipamento->registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e(date('d/m/Y', strtotime($registro->datalimite))); ?></th>
                                        <th><?php echo e($registro->id); ?></th>
                                        <td><?php echo e($registro->user->name); ?></td>
                                        <td><?php if($registro->tipo == 1): ?>
                                            Preventiva
                                        <?php endif; ?>
                                        <?php if($registro->tipo == 2): ?>
                                            Corretiva
                                        <?php endif; ?>
                                        <?php if($registro->tipo == 3): ?>
                                            Urgente
                                        <?php endif; ?></td>
                                        <td>
                                            <a href="<?php echo e(route('registros.show', $registro->id)); ?>"><button class="btn btn-sm btn-outline-primary">Exibir</button></a>
                                            <a href="<?php echo e(route('registros.edit', $registro->id)); ?>"><button class="btn btn-sm btn-outline-warning">Editar</button></a>
                                            <form action="<?php echo e(route('registros.destroy', $registro->id)); ?>" method="post" class="excluir" onsubmit="return confirm('Tem certeza que deseja excluir este registro?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger">Excluir</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Facul\8º PLE\Sistemas WEB\GitHub\2020-03-ple-atividades-CLSKayyo\Atividades\atividade-pratica-02\resources\views/admin/relatorio.blade.php ENDPATH**/ ?>